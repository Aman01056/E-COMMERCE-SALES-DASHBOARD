# E-Commerce Sales Dashboard 📊

This repository contains a Power BI dashboard project that visualizes key metrics for an E-Commerce business, including sales, profit, orders, customer segments, and product performance.

## 📁 Project Files
- `E-COMMERCE SALES DASHBOARD.pbix`: The Power BI dashboard file.

## 📌 Features
- Sales KPIs (Total Sales, Profit, Orders)
- Region-wise and category-wise breakdowns
- Time-series trends (Monthly/Yearly)
- Customer and product segmentation
- Interactive filters and slicers

## 🚀 Getting Started
1. Clone or download this repository.
2. Open `E-COMMERCE SALES DASHBOARD.pbix` in Power BI Desktop.
3. Refresh data sources (if connected to external files).

## 🧾 Requirements
- Power BI Desktop (latest version)

## 📷 Preview
> *(Insert screenshots here if you have them)*

## 💡 Author
- **Your Name Here**
- [LinkedIn](#) | [Email](#)

## 📄 License
This project is licensed under the MIT License. See the `LICENSE` file for details.
